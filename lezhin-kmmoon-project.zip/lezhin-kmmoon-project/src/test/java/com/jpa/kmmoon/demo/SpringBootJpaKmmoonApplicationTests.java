package com.jpa.kmmoon.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaKmmoonApplicationTests {

    @Test
    void contextLoads() {
    }

}
