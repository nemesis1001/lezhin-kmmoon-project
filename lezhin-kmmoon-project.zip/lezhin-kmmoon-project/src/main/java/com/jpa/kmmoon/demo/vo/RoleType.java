package com.jpa.kmmoon.demo.vo;

public enum RoleType {
    ADMIN, USER
}